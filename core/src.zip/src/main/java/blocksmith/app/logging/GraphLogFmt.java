package blocksmith.app.logging;

import blocksmith.domain.block.Block;
import blocksmith.domain.block.BlockId;
import blocksmith.domain.block.BlockPosition;
import blocksmith.domain.connection.Connection;
import blocksmith.domain.connection.PortRef;
import blocksmith.domain.group.GroupId;
import blocksmith.domain.value.ValueType;
import blocksmith.domain.value.ValueType.ListType;
import blocksmith.domain.value.ValueType.SimpleType;
import blocksmith.domain.value.ValueType.VarType;
import java.util.Collection;
import java.util.UUID;

/**
 *
 * @author joost
 */
public final class GraphLogFmt {

    private GraphLogFmt() {
    }

    public static String block(BlockId id) {
        return shortId(id.value());
    }

    public static String blocks(Collection<Block> blocks) {
        var ids = blocks.stream().map(b -> b.id()).toList();
        return blockIds(ids);
    }

    public static String blockIds(Collection<BlockId> ids) {
        return ids.stream()
                .map(GraphLogFmt::block)
                .toList()
                .toString();
    }

    public static String port(PortRef ref) {
        return block(ref.blockId()) + "." + ref.valueId();
    }
    
    public static String valueType(ValueType type) {
        if(type instanceof SimpleType simpleType) {
            return simpleType.raw().getSimpleName();
        }
        if(type instanceof ListType listType) {
            return "List<" + valueType(listType.elementType()) + ">";
        }
        var varType = (VarType) type;
        return varType.name();
    }

    public static String connections(Collection<Connection> connections) {
        return connections.stream()
                .map(GraphLogFmt::connection)
                .toList()
                .toString();
    }

    public static String connection(PortRef from, PortRef to) {
        return port(from) + " -> " + port(to);
    }

    public static String connection(Connection c) {
        return connection(c.from(), c.to());
    }

    public static String group(GroupId id) {
        return shortId(id.value());
    }

    public static String movedBlocks(Collection<BlockPosition> positions) {
        return positions.stream()
                .map(p -> block(p.id()))
                .toList()
                .toString();
    }

    public static String shortId(UUID id) {
        return id.toString().substring(0, 8);
    }

    public static String shortIdOrMissing(UUID id) {
        return id == null ? "<missing-id>" : shortId(id);
    }
}
