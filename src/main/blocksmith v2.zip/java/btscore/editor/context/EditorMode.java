package btscore.editor.context;

/**
 *
 * @author Joost
 */
public enum EditorMode {
    IDLE_MODE,
    PAN_MODE,
    SELECTION_MODE,
    ZOOM_MODE,
    RADIAL_MENU_MODE,
    BLOCK_SEARCH_MODE,
    GROUP_SELECTION_MODE
}
