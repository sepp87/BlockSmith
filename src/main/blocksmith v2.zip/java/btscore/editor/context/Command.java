package btscore.editor.context;

/**
 *
 * @author Joost
 */
public interface Command {

    boolean execute();

}
