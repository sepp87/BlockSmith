package btscore.editor.context;

/**
 *
 * @author joostmeulenkamp
 */
public interface MarkSavedCommand {
    
}
