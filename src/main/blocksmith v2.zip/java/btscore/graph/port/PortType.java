package btscore.graph.port;

/**
 *
 * @author joostmeulenkamp
 */
public enum PortType {
    INPUT,
    OUTPUT
}
