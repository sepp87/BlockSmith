package btscore.graph.port;

/**
 *
 * @author joostmeulenkamp
 */
public interface AutoConnectable {
    
}
