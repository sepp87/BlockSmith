package btscore;


import btscore.UiApp;

/**
 *
 * @author joostmeulenkamp
 */
public class UiAppRunner {

    public void run() {
        //Launch the UI
        UiApp.launch(UiApp.class);
    }
}
