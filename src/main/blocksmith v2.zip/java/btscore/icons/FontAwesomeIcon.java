package btscore.icons;

/**
 *
 * @author joostmeulenkamp
 */
public interface FontAwesomeIcon {

    public String unicode();
}
