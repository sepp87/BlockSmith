package blocksmith.domain.graph;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.UUID;

/**
 *
 * @author joostmeulenkamp
 */
public final class GraphValidator {

    private GraphValidator() {

    }

    public static void validate(Graph graph) {
        var connections = graph.connections();
        verifyConnectionUniqueness(connections);
        verifyInputsConnectedOnlyOnce(connections);
        verifyPortsExist(graph);
    }

    private static void verifyConnectionUniqueness(Collection<Connection> connections) {
        var checked = new HashSet<Connection>();
        for (var connection : connections) {
            if (checked.contains(connection)) {
                throw new IllegalStateException("Graph contains a duplicate connection");
            }
            checked.add(connection);
        }
    }

    private static void verifyInputsConnectedOnlyOnce(Collection<Connection> connections) {
        var checked = new HashSet<PortRef>();
        for (var connection : connections) {
            if (checked.contains(connection.to())) {
                throw new IllegalStateException("INPUT port cannot have multiple incoming connections");
            }
            checked.add(connection.to());
        }
    }

    private static void verifyPortsExist(Graph graph) {
        var blockIndex = new HashMap<UUID, Block>();
        graph.blocks().forEach(e -> blockIndex.put(e.id(), e));

        for (var connection : graph.connections()) {
            verifyPortExists(connection.from(), blockIndex);
            verifyPortExists(connection.to(), blockIndex);
        }
    }

    private static void verifyPortExists(PortRef ref, Map<UUID, Block> blockIndex) {
        if (!blockIndex.containsKey(ref.blockId())) {
            throw new IllegalStateException("Connection refers to a non-existent block: " + ref.blockId());
        }

        var block = blockIndex.get(ref.blockId());
        for (var port : block.ports()) {
            var sameDirection = ref.direction() == port.direction();
            var sameIndex = ref.index() == port.index();
            if (sameDirection && sameIndex) {
                return;
            }
        }
        throw new IllegalStateException("Connection refers to a non-existent port: " + ref);
    }
}
